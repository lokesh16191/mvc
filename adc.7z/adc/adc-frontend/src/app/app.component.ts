import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  message: string = 'Loading...';
  appName: string = 'ADC Application';

  constructor(private http: HttpClient) {}

  ngOnInit() {
    this.http.get<any>('/api/hello').subscribe({
      next: (data) => {
        this.message = data.message;
        this.appName = data.app;
      },
      error: (err) => {
        console.error('Error fetching data:', err);
        this.message = 'Error loading message from backend';
      }
    });
  }
}
