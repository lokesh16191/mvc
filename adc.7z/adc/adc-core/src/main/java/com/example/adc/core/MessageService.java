package com.example.adc.core;

public class MessageService {
    
    public String getWelcomeMessage() {
        return "Hello, Welcome! This message is from ADC-Core module.";
    }
    
    public String getApplicationName() {
        return "ADC Multi-Module Application";
    }
}
