package com.example.adc.web;

import com.example.adc.core.MessageService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/api/hello")
public class HelloServlet extends HttpServlet {
    
    private MessageService messageService = new MessageService();
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        
        PrintWriter out = response.getWriter();
        String message = messageService.getWelcomeMessage();
        String appName = messageService.getApplicationName();
        
        out.print("{\"message\": \"" + message + "\", \"app\": \"" + appName + "\"}");
        out.flush();
    }
}
